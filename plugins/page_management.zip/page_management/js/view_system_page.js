$( document ).ready( function(){
	$( '#view-system-page-table' ).DataTable({});
});

var _for = "";
var _thees = "";
var _page_id = "";

function deletePage( page_id, thees ){
	showConfirmModal( "Confirm", "Are you sure you want to delete this page ? Deleting the page will also delete the corresponding functionality. We recommend you to use the Edit Page, in case you want to edit the page/functionality information ! ", "Yes", "No" );
	_for = "delete_page";
	_thees = thees;
	_page_id = page_id;
}

function deletePageGroup( thees ){
	showConfirmModal( "Confirm", "Are you sure you want to delete this page group ? The pages present in this group will be moved to the \"All Other Pages\" group ", "Yes", "No" );
	_for = "delete_page_group";
	_thees = thees;
	_page_group_id = $( '#selected_page_group_id' ).val();
}

function editPage( page_id, thees ){
	post( 'adminpanel.html?what_do_you_want=edit_system_page', { 'page_id' : page_id, 'page_group_id' : $( '#selected_page_group_id' ).val() } );
}

function yesClicked( forr ){
	if( _for == "delete_page" ){
		$( _thees ).attr( 'disabled', "disabled" );
		
		$.ajax({
			url  : 'webservice.php',
			type : 'POST',
			data :  { 'what_do_you_want': 'delete_page', 'page_id' : _page_id },
			success : function( returned_data ){
				console.log( returned_data );
				var jSon = $.parseJSON( returned_data );
				
				$( _thees ).removeAttr( 'disabled' );
				
				$.each( jSon, function(){
					if( this[ 'type' ] == "error" ){
						showModal( "error", this[ 'info' ] );
						return;
					}
					if( this[ 'type' ] == "success" ){
						showModal( "success", this[ 'info' ] );
						$( _thees ).attr( 'disabled', "disabled" );
						$( _thees ).parent().parent().remove();
						return;
					}
				});
			}
		});
	}
	else if( _for == "delete_page_group" ){
		$( _thees ).attr( 'disabled', "disabled" );
		
		$.ajax({
			url  : 'webservice.php',
			type : 'POST',
			data :  { 'what_do_you_want': 'delete_page_group', 'page_group_id' : _page_group_id },
			success : function( returned_data ){
				console.log( returned_data );
				var jSon = $.parseJSON( returned_data );
				
				$( _thees ).removeAttr( 'disabled' );
				
				$.each( jSon, function(){
					if( this[ 'type' ] == "error" ){
						showModal( "error", this[ 'info' ] );
						return;
					}
					if( this[ 'type' ] == "success" ){
						showModal( "success", this[ 'info' ] );
						setTimeout( function(){
							refreshPage();
						}, 2000 );
						return;
					}
				});
			}
		});
	}
}

function noClicked( forr ){
	$( '#modal-confirm' ).removeClass( 'md-show' );
}

// Change Privilege Group Dropdown
function changePageGroup( id ){
	var selected_page_group_id = $( '#'+id ).val();
	// alert( selected_privilege_group_id );
	post( 'adminpanel.html?what_do_you_want=view_system_page', { 'selected_page_group_id' : selected_page_group_id } );
}