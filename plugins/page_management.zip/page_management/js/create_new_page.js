// app.js
// create angular app
var createPageValidation = angular.module('createPageValidation', []);

// create angular controller
createPageValidation.controller('createPageController', function($scope) {
  // function to submit the form after all validation has occurred            
	$scope.submitForm = function( isValid,event ) {
		event.preventDefault();
		
		//to check dropdown is  selected for page group name
		 var page_group_id_value = $( '#page_group_id' ).val();
		 if( ( page_group_id_value == null ) || ( page_group_id_value == "" ) ){
			 showModal( "error", "You have not selected any Page Group. Please select one and try again !" );
			 return;
		 }
		 
		//to check dropdown is selected for page sequence
		 var page_sequence_value = $( '#page_sequence' ).val();
		 if( ( page_sequence_value == null ) || ( page_sequence_value == "" ) ){
			 showModal( "error", "You have not selected any Page Sequence. Please select one and try again !" );
			 return;
		 }
		 
		//to check dropdown is selected for visibility
		 var visible_value = $( '#visible' ).val();
		 if( ( visible_value == null ) || ( visible_value == "" ) ){
			 showModal( "error", "You have not selected any Visibility. Please select one and try again !" );
			 return;
		 }
		 
		//to check dropdown is selected for functionality
		 var functionality_id_value = $( '#functionality_id' ).val();
		 if( ( functionality_id_value == null ) || ( functionality_id_value == "" ) ){
			 showModal( "error", "You have not selected any Functionality. Please select one and try again !" );
			 return;
		 }
		 
	    // check to make sure the form is completely valid
	    if ( ! isValid ) {
	      showModal( "error", "Please check your form fields again !" );
	      return;
	    }
    
	    $.ajax({
	    	url:'webservice.php',
	    	type:'POST',
	    	data:  $( '#form_create_page' ).serialize(),
	    	success: function( returned_data ){
	    		console.log( returned_data );
	    		
	    		var jSon = $.parseJSON( returned_data );
	    		$.each( jSon , function(){
	    			if( this[ 'type' ] == "error" ){
	    				showModal( "error", this[ 'info' ] );
	    				return;
	    			}
	    			if( this[ 'type' ] == "success" ){
	    				showModal( "success", this[ 'info' ] );
	    				setTimeout( function(){
	    					refreshPage();
	    				}, 1000 );
	    				return;
	    			}
	    		});
	    	}
	    });
	};
  
  $scope.submitPageGroup = function( isValid, event ){
	  event.preventDefault();
	  
	 //to check dropdown is  selected for page group
	 var page_group_value = $( '#page_group_sequence' ).val();
	 if( ( page_group_value == null ) || ( page_group_value == "" ) ){
		 showModal( "error", "You have not selected any Page Group. Please select one and try again !" );
		 return;
	 }
	 
	// check to make sure the form is completely valid
	    if ( ! isValid ) {
	      showModal( "error", "Please check your form fields again !" );
	      return;
	    }
	  
	  $.ajax({
		  url:'webservice.php',
		  type:'POST',
		  data: $( '#form_create_page_group' ).serialize(),
		  success: function( returned_data ){
			  console.log( returned_data );
			  var jSon = $.parseJSON( returned_data );
			  
			  $.each(jSon , function(){
				  if( this[ 'type' ] == 'error' ){
					  showModal( "error", this[ 'info' ] );
					  return;
				  }
				  if( this[ 'type' ] == 'success' ){
					  showModal( "success", this[ 'info' ] );
					  setTimeout( function(){
	    					refreshPage();
	    				}, 2000 );
					  return;
				  }
			  });
		  }
	  });
  };
  
  $scope.createPage = function(){
	  $( '#createPageForm' ).addClass( 'hidden' );
	  $( '#createPageGroupForm' ).addClass( 'hidden' );
	  $( '#createPageForm' ).removeClass( 'hidden' );
  };
  
  $scope.createPageGroup = function(){
	  $( '#createPageForm' ).addClass( 'hidden' );
	  $( '#createPageGroupForm' ).addClass( 'hidden' );
	  $( '#createPageGroupForm' ).removeClass( 'hidden' );
  }

});