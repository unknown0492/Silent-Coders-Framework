<?php 
	checkIfLoggedIn();	
	checkPrivilegeForPage( basename( __FILE__, ".php" ) );
?>
<!-- BEGIN MAIN CONTENT -->
<div id="main-content" ng-app="createPageValidation" ng-controller="createPageController" >
		<div class="row">
			<div class="col-md-12 col-lg-6 col-lg-offset-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">Create <strong>Page/Group</strong></h3>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                	<button type="button" class="btn btn-lg btn-block btn-primary" name="createPageGroup" id="createPageGroup" ng-click="createPageGroup()"><i class="fa fa-facebook pull-left"></i>Create Page Group</button>
                            	</div>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <button type="button" class="btn btn-lg btn-block btn-primary" name="createPage" id="createPage" ng-click="createPage()"><i class="fa fa-facebook pull-left"></i>Create New Page</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
         	</div>      
    
    
    
    <!-- form to create page group and enter group name  -->
	<div class="row hidden" id="createPageGroupForm" >
    	<div class="col-md-12 col-lg-6 col-lg-offset-3">
    		<br>
    		<br>
        	<div class="panel panel-default">
				<div class="panel-body">
	            	<div class="row-fluid">
	            		<form name="form_create_page_group" id="form_create_page_group" method="POST" 
	            			ng-submit="submitPageGroup(form_create_page_group.$valid,$event)" novalidate >
		                	<h3><strong>Create</strong> New Page Group</h3>
		                    <br>
		                   
		                    <div>
		                    	<label><strong>Page Group Name*</strong></label>
		                    </div>
		                    <div class="input-group transparent">
		                    	<span class="input-group-addon bg-blue">
		                        	<i class="fa fa-font"></i>
						        </span>
		                		<input type="text" class="form-control" placeholder="Page Group Name" name="page_group_name" 
		                				id="page_group_name" ng-model="page_group_name" ng-pattern="/^[a-zA-Z0-9 ]*$/" required />
							</div>
							<span class="label label-success">Only use lowercase, uppercase alphabets, digits and white spaces</span>
							<p ng-show="form_create_page_group.page_group_name.required && !form_create_page_group.page_group_name.required" 
		                		class="help-block" style="color:red;">Page Group Name is required</p>
		                	<p class="help-block" ng-show="form_create_page_group.page_group_name.$error.pattern" style="color:red;" >You have used invalid characters. Please refer to the above rules for `Page Group Name`</p>
		                    <br>
		                    <br>
		                    
		                    <div>
		                    	<label><strong>Icon</strong></label>
		                    </div>
		                    <div class="input-group transparent">
		                    	<span class="input-group-addon bg-blue">
		                        	<i class="fa fa-wrench"></i>
						        </span>
		                		<input type="text" class="form-control" placeholder="Icon" name="icon" 
		                			id="icon" ng-model="icon" ng-pattern="/^[a-zA-Z_ \s\-]*$/" />
							</div>			
		                	<span class="label label-success">Use icons from fontawesome.io. And should be in the format `fa fa-iconname`</span>
							<p class="help-block" ng-show="form_create_page_group.icon.$error.pattern" style="color:red;">You have used invalid characters. Please refer to the above rules for `icon`</p>
		                    <br />
		                    <br />
		                    
							<div class="col-md-12 input-group">
			                    <label><strong>Page Group Sequence*</strong></label>
		                    	<select class="form-control" id="page_group_sequence" name="page_group_sequence"  title="Choose Group Sequence" required>
		                        	<?php
		                        	$sql = "Select MAX(page_group_sequence) as a FROM page_group ";
		                        	$result_set = selectQuery( $sql );
		                        	while( ( $val = mysqli_fetch_assoc( $result_set ) ) != NULL ){
		                        		$maxSequence = $val[ 'a' ] + 1;
		                        	}
		                        	for( $i=1 ; $i < 101 ; $i++ ){
		                        	?>
		                        		<option value="<?= $i ?>" <?php if( $i == $maxSequence ){ echo 'selected'; } ?> > <?= $i ?></option>	
		                        	<?php
		                        	}
		                        	?>
		                        </select>    
							</div>
		                    <span class="label label-success">Select a page sequence number for the page</span>
							<p ng-show="form_create_page_group.page_group_sequence.required && !form_create_page_group.page_group_sequence.required" 
		                		class="help-block" style="color:red;" >Page Sequence is required</p>
		                	<br /><br />
		                    
		                    <input type="hidden" value="create_page_group" name="what_do_you_want" id="what_do_you_want" />
		                    <input type="submit" value="Create" class="btn btn-primary" name="submit_form_create_page_group" id="submit_form_create_page_group" ng-disabled="form_create_page_group.$invalid" />
		                    <input type="reset" value="Reset" class="btn btn-danger" name="reset_form_create_page_group" id="reset_form_create_page_group" />
	                    </form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- /form ends here for privilege group -->
    
                
	<!-- Create Page Form -->
	<div class="row hidden" id="createPageForm">
    	<div class="col-md-12 col-lg-6 col-lg-offset-3">
    		<br>
    		<br>
        	<div class="panel panel-default">
				<div class="panel-body ">
	            	<div class="row-fluid">
	            		<form name="form_create_page" id="form_create_page" method="POST" 
	            			ng-submit="submitForm(form_create_page.$valid,$event)" novalidate >
		                	<h3><strong>Create</strong> New Page</h3>
		                    <br>
		                    
		                    <div class="col-md-12 input-group">
			                    <label><strong>Select Page Group*</strong></label>
		                    	<select class="form-control" id="page_group_id" name="page_group_id"  title="Select Page Group" required>
		                        	<option value="">Choose one Page Group</option>
		                        	<?php 
		                        	$sql = "Select * FROM page_group";
		                        	$result_set = selectQuery( $sql );
		                        	while( ( $val = mysqli_fetch_object( $result_set ) ) != NULL ){
		                        	?>
		                        		<option value="<?=$val->page_group_id ?>"><?=$val->page_group_name ?></option>	
		                        	<?php
		                        	}
		                        	?>
		                        </select>
							</div>
							<span class="label label-success">Select one Page Group from the above dropdown list</span>
		                    <p ng-show="form_create_page.page_group_id.required && !form_create_page.page_group_id.required" 
		                			class="help-block" style="color:red;" >Please select a Page Group</p>
		                    <br>
		                    <br>
		                    
		                    <div>
		                    	<label><strong>Page Name*</strong></label>
		                    </div>
		                    <div class="input-group transparent">
		                    	<span class="input-group-addon bg-blue">
		                        	<i class="fa fa-font"></i>
						        </span>
		                		<input type="text" class="form-control" placeholder="Page Name" name="page_name" 
		                				id="page_name" ng-model="page_name" ng-pattern="/^[a-z_]*$/" required />
							</div>
							<span class="label label-success">Only use lowercase and underscores. Use the sample format `some_name_page`</span>
							<p ng-show="form_create_page.page_name.required && !form_create_page.page_name.required" 
		                		class="help-block" style="color:red;">Page Name is required</p>
		                	<p class="help-block" ng-show="form_create_page.page_name.$error.pattern" style="color:red;" >Please use above rules for `Page Name`</p>
		                    <br><br>
							
							<div class="col-md-12 input-group">
			                    <label><strong>Page Sequence*</strong></label>
		                    	<select class="form-control" id="page_sequence" name="page_sequence"  title="Choose Page Sequence" required>
		                        	<?php
		                        	$sql = "Select MAX(page_sequence) as a FROM pages ";
		                        	$result_set = selectQuery( $sql );
		                        	$val = mysqli_fetch_assoc( $result_set );
		                        		echo $maxSequence = $val[ 'a' ] + 1;
		                        	
		                        	for( $i=1 ; $i < 101 ; $i++ ){
		                        	?>
		                        		<option value="<?= $i ?>" <?php if( $i == $maxSequence ){ echo 'selected'; } ?> > <?= $i ?></option>	
		                        	<?php
		                        	}
		                        	?>
		                        </select>
		                        
							</div>
							<span class="label label-success">Select a page sequence number for the page</span>
		                    <p ng-show="form_create_page.page_sequence.required && !form_create_page.page_sequence.required" 
		                		class="help-block" style="color:red;" >Page Sequence is required</p>
		                    <br /><br />
		                    	                    
		                    <div>
		                    	<label><strong>Icon</strong></label>
		                    </div>
		                    <div class="input-group transparent">
		                    	<span class="input-group-addon bg-blue">
		                        	<i class="fa fa-wrench"></i>
						        </span>
		                		<input type="text" class="form-control" placeholder="Icon" name="icon" 
		                			id="icon" ng-model="icon" ng-pattern="/^[a-zA-Z_ -]*$/" />
							</div>			
		                	<span class="label label-success">Use icons from fontawesome.io. And should be in the format `fa fa-iconname`</span>
							<p class="help-block" ng-show="form_create_page.icon.$error.pattern" style="color:red;">Only Alphabets and Few Special Characters are allowed</p>
		                    <br /><br />
		                    
		                    <div class="col-md-12 input-group">
			                    <label><strong>Visible</strong></label>
		                    	<select class="form-control" id="visible" name="visible" title="Select Visiblility">
		                        	<option value="0"> 0 </option>
		                        	<option value="1"> 1 </option>
		                        </select>
							</div>
		                    <span class="label label-success">Choose 0 if you don't want this page to be displayed, and 1 if you want it to be displayed</span>
							<br /><br />
		                    
		                    <div>
		                    	<label><strong>Page Title*</strong></label>
		                    </div>
		                    <div class="input-group transparent">
		                    	<span class="input-group-addon bg-blue">
		                        	<i class="fa fa-wrench"></i>
						        </span>
		                		<input type="text" class="form-control" placeholder="Page Title" name="page_title" 
		                			id="page_title" ng-model="page_title" ng-pattern="/^[a-zA-Z_ !@#$%*()\[\]?&-,/]*$/" required />
							</div>
							<span class="label label-success">Some special characters are not allowed for `Page Title`</span>
							<p ng-show="form_create_page.page_title.required && !form_create_page.page_title.required" 
		                		class="help-block" style="color:red;">Page Title is required</p>			
		                	<p class="help-block" ng-show="form_create_page.page_title.$error.pattern" style="color:red;">Please remove some special characters from the `Page Title`</p>
		                    <br /><br />
							
		                    <div class="col-md-12 input-group">
			                    <label><strong>Functionality*</strong></label>
		                    	<select class="form-control" id="functionality_id" name="functionality_id"  title="Choose funtionality">
		                    		<option value="none">Select Functionality</option>
		                        	<?php
		                        	$sql 		= "Select * FROM functionalities WHERE functionality_name LIKE '%_page'";
		                        	$result_set = selectQuery( $sql );
		                        	while( ( $val = mysqli_fetch_assoc( $result_set ) ) != NULL ){
		                        	?>
		                        		<option value="<?=$val[ 'functionality_id' ]; ?>" > <?= $val[ 'functionality_name' ] . " : " .$val[ 'functionality_description' ] ?></option>	
		                        	<?php
		                        	}
		                        	?>
		                        </select>
							</div>
		                    <span class="label label-success">Select the corresponding Functionality Name for this page</span>
							<br /><br />
		                    
		                    <div>
		                    	<label><strong>Description</strong></label>
		                    </div>
		                    <div class="input-group transparent">
		                		<textarea class="form-control" cols="75" id="description" name="description" 
		                			placeholder="Description" ng-model="description" ng-pattern="/^[a-zA-Z0-9 ,.#$&*\[\]]*$/" >
		                		</textarea>
							</div>
		                	<span class="label label-success">Use only from lowercase, uppercase alphabets, digits, white spaces and the special characters ,.#$&*[]</span>
							<p class="help-block" ng-show="form_create_page.description.$error.pattern" style="color:red;">Special Characters not allowed except comma</p>
		                    <br /><br />
		      				
		      				<div>
		                    	<label><strong>Tags</strong></label>
		                    </div>
		                    <div class="input-group transparent">
		                		<textarea class="form-control" cols="75" id="tags" name="tags" 
		                			placeholder="Tags" ng-model="tags" ng-pattern="/^[a-zA-Z0-9 ,]*$/" >
		                		</textarea>
							</div>
		                	<span class="label label-success">Use comma-separated values of keywords</span>
							<p class="help-block" ng-show="form_create_page.tags.$error.pattern" style="color:red;">Special Characters not allowed except comma</p>
		                    <br><br>    
		      				
		      				<div>
		                    	<label><strong>Image</strong></label>
		                    </div>
		                    <div class="input-group transparent">
		                    	<span class="input-group-addon bg-blue">
		                        	<i class="fa fa-wrench"></i>
						        </span>
		                		<input type="url" class="form-control" placeholder="Image" name="image" id="image" ng-model="image" />
							</div>		
		                	<span class="label label-success">Input a URL for the image. This URL will be used for the meta tags </span>
							<p class="help-block" ng-show="form_create_page.image.$error.url" style="color:red;">Please enter Valid URL.</p>
		                    <br><br>
		      				
		      				<div>
		                    	<label><strong>Content</strong></label>
		                    </div>
		                    <div class="input-group transparent">
		                		<textarea class="form-control" cols="75" id="content" name="content" 
		                			placeholder="Content" ng-model="content" ng-pattern="/^[a-zA-Z0-9 ,.#$&*\[\]]*$/" >
		                		</textarea>
							</div>
		                	<span class="label label-success">Use only from lowercase, uppercase alphabets, digits, white spaces and the special characters ,.#$&*[]</span>
							<p class="help-block" ng-show="form_create_page.content.$error.pattern" style="color:red;">Please use above rules for the `Content`</p>
		                    <br><br>
		      				
		                    <input type="hidden" value="create_page" name="what_do_you_want" id="what_do_you_want" />
		                    <input type="submit" value="Create" class="btn btn-primary" name="submit_form_create_page" id="submit_form_create_page" ng-disabled="form_create_page.$invalid" />
		                    <input type="reset" value="Reset" class="btn btn-danger" name="reset_form_create_page" id="reset_form_create_page" />
	                    </form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- /Create Page Form -->
	

</div>
<!-- END MAIN CONTENT -->

    
    <!-- BEGIN PAGE LEVEL SCRIPTS -->
    <script src="assets/plugins/bootstrap-dropdown/bootstrap-hover-dropdown.min.js"></script>
	<script src="assets/plugins/bootstrap-select/bootstrap-select.js"></script>
	<script src="js/angular.min.js"></script>
    <script src="plugins/<?=$plugin_name ?>/js/<?=basename( __FILE__, ".php" ) ?>.js"></script>
    <!-- END PAGE LEVEL SCRIPTS -->
