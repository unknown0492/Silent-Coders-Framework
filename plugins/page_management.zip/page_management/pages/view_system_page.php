<?php 
	checkIfLoggedIn();
	checkPrivilegeForPage( basename( __FILE__, ".php" ) );
?>
<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/dataTables.css" />
        <div id="main-content">
            <div class="row">
                <div class="col-md-12">
                	<h3><strong>View</strong> Pages</h3>
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="row">
                            	<?php 
	                            	$sql = "Select * FROM page_group WHERE page_group_id <> 0 ORDER BY page_group_sequence";
	                            	$result_set0 = selectQuery( $sql );
	                            	$result_set_temp = $result_set0;
                            	?>
                            	<div class="col-lg-5 col-md-5 col-sm-4 col-xs-12">
                                    <label><strong>Select Page Group : </strong></label>
                                    <select data-style="input-md btn-default" data-live-search="true" name="selected_page_group_id" id="selected_page_group_id" onchange="changePageGroup(this.id);">
                                    	<?php 
                                    		while( ( $val0 = mysqli_fetch_object( $result_set0 ) ) != NULL ){
                                    	?>
                                    		<option value="<?=$val0->page_group_id ?>" <?=(@$_REQUEST[ 'selected_page_group_id' ]==$val0->page_group_id)?"selected":"" ?>><?=$val0->page_group_name ?></option>
                                    	<?php
                                    		}
                                    	?>
                                    	<option value="0" <?=(@$_REQUEST[ 'selected_page_group_id' ]==="0")?"selected":"" ?>>All Other Pages</option>
                                	</select>
                                	<button style="margin-bottom: 10px; margin-left: 0px;" type="button" class="btn btn-danger btn-sm" id="delete_page_group_button" onclick="deletePageGroup( this );"><i class="fa fa-trash-o"></i> Delete Group</button>
                                	<br />
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12 table-responsive">
                                    <table id="view-system-page-table" class="table table-tools table-hover table-striped table-bordered">
                                        <thead>
                                        	<tr>
								                <th class="text-center">Sr. No.</th>
								                <th class="text-center"><strong>Page Name</strong></th>
								                <th class="text-center"><strong>Page Title</strong></th>
								                <th class="text-center"><strong>Page Sequence</strong></th>
								                <th class="text-center"><strong>Options</strong></th>
								            </tr>
								        </thead>
								        <tbody>
								        	<?php 
									        	//$sql = "Select * FROM privilege_group ORDER BY privilege_group_sequence";
	                            				//$result_set0 = selectQuery( $sql );
									        	$count = 1;
									        	//while( ( $val0 = mysqli_fetch_object( $result_set0 ) ) != NULL ){
									        		$pgi = ( @$_REQUEST[ 'selected_page_group_id' ]!="")?$_REQUEST[ 'selected_page_group_id' ]:1;
									        		$page_group_id = $pgi;//$val0->page_group_id;
									        		$sql = "SELECT DISTINCT p.`page_id`,p.`page_name`,p.`page_title`,p.`title`,p.`page_sequence`,p.`content`
									        				FROM pages p,page_group pg , pages_groups pgs
									        				WHERE p.`page_id` = pgs.`page_id`
									        				AND pg.`page_group_id` = pgs.`group_id`
									        				AND pgs.`group_id` = '$page_group_id' ";
									        		$result_set = selectQuery( $sql );
									        		
									        		while( ( $val = mysqli_fetch_assoc( $result_set ) ) != NULL ){
									        		?>
											<tr>
												<td class="text-center"><?=$count++; ?></td>
												<td class="text-center"><?=$val[ 'page_name' ]; ?></td>
												<td class="text-center"><?=$val[ 'page_title' ]; ?></td>
												<td class="text-center"><?=$val[ 'page_sequence' ]; ?></td>
												<td class="text-center">
													<button type="button" class="btn btn-success btn-sm" onclick="javascript:editPage( '<?=$val[ 'page_id' ] ?>', this );" title="Edit Page" alt="Edit Page"><i class="fa fa-pencil"> </i></button>
													<button type="button" class="btn btn-danger btn-sm" onclick="javascript:deletePage( '<?=$val[ 'page_id' ] ?>', this );" title="Delete Page" alt="Delete Page"><i class="fa fa-trash-o"> </i></button>
												</td>
        									</tr>
        										<?php 
        										}
								        	//}
        										?>
								        </tbody>
								    </table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
        </div>
        <!-- END MAIN CONTENT -->

    
    <!-- BEGIN PAGE LEVEL SCRIPTS -->
    <script src="assets/plugins/bootstrap-switch/bootstrap-switch.js"></script>
    <script src="assets/plugins/bootstrap-progressbar/bootstrap-progressbar.js"></script>
    <script src="assets/plugins/datatables/dynamic/jquery.dataTables.min.js"></script>
    <script src="assets/plugins/datatables/dataTables.bootstrap.js"></script>
    <script src="assets/plugins/datatables/dataTables.tableTools.js"></script>
    <script src="assets/plugins/datatables/table.editable.js"></script>
    <script src="assets/js/ecommerce.js"></script>
    <!-- END  PAGE LEVEL SCRIPTS -->
    
    <script src="plugins/<?=$plugin_name ?>/js/<?=basename( __FILE__, ".php" ) ?>.js"></script>
